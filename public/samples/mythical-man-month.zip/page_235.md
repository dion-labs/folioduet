### Chapter 7. Why Did the Tower of Babel Fail?

Chapter 7. Why Did the Tower of Babel Fail?

7.1 The Tower of Babel project failed because of lack of communication and of its consequent, organization.

Communication

7.2 "Schedule disaster, functional misfit, and system bugs all arise because the left hand doesn't know what the right hand is doing." Teams drift apart in assumptions. 7.3 Teams should communicate with one another in as many ways as possible: informally, by regular project meetings with technical briefings, and via a shared formal project workbook. [And by electronic mail.]

### Project Workbook

7.4 A project workbook is "not so much a separate document as it is a structure imposed on the documents that the project will be producing anyway." 7.5 "All the documents of the project need to be part of this [workbook] structure." 7.6 The workbook structure needs to be designed carefully and early. 7.7 Properly structuring the on-going documentation from the beginning "molds later writing into segments that fit into that structure" and will improve the product manuals. 7.8 "Each team member should see all the [workbook] material." [I would now say, each team member should be able to see all of it. That is, World-Wide Web pages would suffice.] 7.9 Timely updating is of critical importance. 7.10 The user needs to have attention especially drawn to changes since his last reading, with remarks on their significance. 7.11 The OS/360 Project workbook started with paper and switched to microfiche. 7.12 Today [even in 1975], the shared electronic notebook is a
