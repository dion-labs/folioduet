### Index

Fagg, P., 24 Falkoff, A. D., 296

family, software product, 268 Farr, L., 88, 296 Fast Fourier Transform, 102 featuritis, 257 Feigenbaum, E. A., 191 Ferrell, J., 287 file, dummy, 148 miniature, 148 filters, 187 Fjelstadt, 304 floorspace, 239 flow arrow, 174 flow chart, 167, 185, 194, 248, 300 forecast, 109, 239 formal definition, 63, 234 formal document, 111 formal progression of release, 133 formality, of written proposals,

Fortran, 45, 102, 203, 302 Fortran, H., 99 FoxPro database, 287 Franklin, B. (Poor Richard), 87 Franklin, J. W., 134 frequency data, 306 frequency guessing, 257, 259 fusion, 277

### Galloping Gertie, Tacoma Narrows Bridge, 264

Gantt chart, 265 General Electric Company, 216 generator, 193, 283 gIBIS, 259, 306 Ginzberg, M. G., 301 Glass, R. L., 214, 226, 304, 305 Glegg, G. L., 294 Global Positioning System, 257

GO TO, 170 God, 42, 184, 232, 289, 291, £x

Godel, 213 Goethe, J. W. von, 163 Gold, M. M., 146, 246, 300 Goldstine, H. H., 170,194, 301 Gordon, P., mi GOTO, 300 Grafton, R. B., 302 Grant, E. E., 29, 30, 88, 294, 296 \graph, 185, 216 \ structure, 248 graphical programming, 194, 302 great designer, 180, 202, 284 Greenwald, I. D., 295 growing software, 180, 200, 212,

Gruenberger, R, 147, 294, 300 Hamilton, F., 291

### Hamlen, 304

hardware, computer, 181 Hardy, H., 97 Harel, D. L., 212, 214, 270, 304,

305, 307 Harr, J., 90, 93,137, 237, 299, xi Hayes-Roth, R., viii Heilmeyer, G., 307 Heinlein, R. A., 81, 296 Hennessy, J., 306 Henricksen, J. O., 299 Henry, P., 253 Herzberg, F., 210, 304 Hetzel, W. C, 299 Hezel, K. D., 301 hierarchical structure, 189, 212,

high-level language, See language, high-level Hoare, C. A. R., 300, 308
