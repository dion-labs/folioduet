Index

program name, 174 program products, 273 program structure graph, 170,

program, 4 auxiliary, 149 self-documenting, 171 programmer retraining, 220, 221 programming environment, 187 programming language, 221 programming product, 5, 116,

programming system, 6 programming systems product,

4, 230 programming systems project,

programming, automatic, 193 graphical, 194 visual, 194 progressive refinement, 267, 299 Project Mercury Real-Time

System, 56 project workbook, 235 promotion, in rank, 120 prototyping, rapid, 180,199, 270 Publilius, 87 purple-wire technique, 149 purpose, of a program, 165, 249 of a variable, 174

277,308 quality, 217 quantization, of change, 62,118,

150,246 of demand for change, 117

### Raeder, G., 302

raise in salary, 120

### Ralston, A., 300

rapid prototyping, 180,199, 270 real-time system, 301 realism, 212, 226 realization, step in creation, 49,

143, 256, 266 refinement, progressive, 143,

267, 299 requirements, 199 regenerative schedule disaster, 21 Reims Cathedral, 41 release, program, 121, 185, 217,

243, 244 reliability, 186 remote job entry, 58 repartitioning, 24, 232, 275 representation, of information,

102, 239 requirements refinement, 199 rescheduling, 24 responsibility, versus authority,

8,231 Restaurant Antoine, 13 / reusable component, 210/ reuse, 222, 224, 269, 273, 285 Reynolds, C. H., 294, 301 role conflict, reducing, 157 ROM, read-only memory, 234 Roosevelt, F. D., 115, 298 Rosen, S., 300 Royce, W. W., 265, 307 Rustin, R., 300, 303, 307 Ruth, G. H. (Babe), 87

Sackman, H., 20, 29, 88, 294, 296 Salieri, A., 202

Saltzer, J. H., 298, 299 Sayderman, B. B., 210, 304 Sayers, D. L., 15, 209, 303 scaffolding, 34, 148, 246
