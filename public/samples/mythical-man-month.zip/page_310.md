Index Bell Telephone Laboratories, 90,

119, 133, 137, 142, 158, 237,

293, xi, 308 Bell, C. G., 64, 296, viii Bengough, W., 107 Bennington, H. D., 305 beta version, 240 Bible, 255 Bierly, R., viii Blaauw, G. A., 45, 49, 62, 63, 294 Bloch, E., i Blum, B., 210 Boehm, B. W., 217, 237, 273, 283,

303, 306, 308, viii Boehm, E. M., 295 Boes, H., ix Bohl, M., 302 Bohm, C., 144, 300 Booch, G., 302 Boudot-Lamotte, E., 40 brass bullet, 219 breakthrough, 186 Breughel, P. , the Elder, 73 Brooks's Law, 25, 274 Brooks, F. P. Jr., 102, 226, 229,

237, 294, 297, 300, 301, 303, i Brooks, K. P., 216, 224, 306, viii Brooks, N. G., v, viii Buchanan, B., viii Buchholz, W., 294 budget, 6,108, 110, 239 access, 99, 238 size, 100, 238 bug, 142,143, 195, 209, 231, 235,

242, 243, 244, 245, 272 documented, 148 Build-every-night approach, 270 build, incremental, 270 system, 147, 246, 301 build-to-budget strategy, 268 build-up, manpower, 179

building a program, 200 bullet, brass, 219 silver, 179, 207, 212, 214, 226,

303, 304 Burke, E., 253 Burks, A. W., 194 Burris, R., xii Bush, V., 281, 291, 308 Butler, S., 229 buy versus build, 197

C++, 220, 285,305 Cambridge Multiple-Access

System, 298 Cambridge University, 133 Campbell, E., 121, 242, 298 Canova, A., 153 Capp, A., 80 Carnegie-Mellon University, 78 CASE statement, 144 Case, R. P., viii, xi Cashman, T. J., 169 cathedral, 41 change summary, 77, 78 change, 117 control of, 149 design, 166, 241, 298 organization, 118 changeability, 117, 184, 241 channel, 45 chemical engineering, 116, 287,

chief programmer, 32, 232 ClarisWorks, 219 class, 189, 222, 225, 272 Clements, P. C., 307, 308 clerk, program, 33 client-server system, 282 Clingen, C. T., 298, 299 COBOL, 199, 203, 218 Codd, E. R, 146, 300
