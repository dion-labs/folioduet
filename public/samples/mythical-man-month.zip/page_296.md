5. Falkoff, A. D., K. E. Iverson, E. H. Sussenguth, "A formal description of System/360," ZBM Systems Journal, 3, 3 (1964), pp. 198-261. 6. Bell, C. G., and A. Newell, Computer Structures. New York: McGraw-Hill, 1970, pp. 120-136, 517-541. 7. Bell, C. G., private communication.

### Chapter 7

1. Parnas, D. L., "Information distribution aspects of design methodology," Carnegie-Mellon Univ., Dept. of Computer Science Technical Report, February, 1971. 2. Copyright 1939, 1940 Street & Smith Publications, Copyright 1950, 1967 by Robert A. Heinlein. Published by arrangement with Spectrum Literary Agency.

### Chapter 8

1. Sackman, H., W. J. Erikson, and E. E. Grant, "Exploratory experimentation studies comparing online and offline programming performance," CACM, 11, 1 (Jan., 1968), pp. 3-

11.

2. Nanus, B., and L. Farr, "Some cost contributors to largescale programs," AFIPS Proc. SJCC, 25 (Spring, 1964), pp.

239-248.

3. Weinwurm, G. F., "Research in the management of computer programming," Report SP-2059, System Development

Corp., Santa Monica, 1965.

4. Morin, L. H., "Estimation of resources for computer programming projects," M. S. thesis, Univ. of North Carolina,

Chapel Hill, 1974.

5. Portman, C., private communication.

6. An unpublished 1964 study by E. F. Bardain shows programmers realizing 27 percent productive time. (Quoted by
