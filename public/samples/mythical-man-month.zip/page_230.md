Propositions of The Mythical Man-Month: True or False?

Much more is known today about software engineering than was known in 1975. Which of the assertions in the original 1975 edition have been supported by data and experience? Which have been disproved? Which have been obsoleted by the changing world? To help you judge, here in outline form is the essence of the 1975 book—assertions I believed to be true: facts and ruleof-thumb-type generalizations from experience—extracted without change of meaning. (You might ask, "If this is all the original book said, why did it take 177 pages to say it?") Comments in brackets are new.

Most of these propositions are operationally testable. My hope in putting them forth in stark form is to focus readers' thoughts, measurements, and comments.

### Chapter 1. The Tar Pit

1.1

A programming systems product takes about nine times

as much effort as the component programs written separately for private use. I estimate that productizing imposes a factor of three; and that designing, integrating, and testing components into a coherent system imposes a factor of three; and that these cost components are essentially independent of each other. 1.2 The craft of programming "gratifies creative longings built deep within us and delights sensibilities we have in common with all men," providing five kinds of joys: • The joy of making things

The joy of making things that are useful to other people 9 The fascination of fashioning puzzle-like objects of interlocking moving parts • The joy of always learning, of a nonrepeating task • The delight of working in a medium so tractable— pure thought-stuff—which nevertheless exists, moves, and works in a way that word-objects do not.
