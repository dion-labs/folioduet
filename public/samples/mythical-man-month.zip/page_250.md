Propositions of The Mythical Man-Month: True or False?

### Original Epilogue E.I

Software systems are perhaps the most intricate and complex (in terms of number of distinct kinds of parts) of the things humanity makes. E.2 The tar pit of software engineering will continue to be sticky for a long time to come.
