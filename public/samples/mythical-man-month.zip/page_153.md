### Hatching a Catastrophe
