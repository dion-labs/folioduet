### Index Homer, 255

### Hopkins, M., 299

Huang, W., 222, 305 hustle, 155, 247 HyperCard, 285 hypertext, 281, 291, 306

IBM 1401, 45, 65, 130 IBM 650, 43, 102

IBM 701, 131 IBM 7030 Stretch computer, 44,

47, 55, 291, 300, i IBM 704, 55 IBM 709, 55, 57, 181 IBM 7090, 55, 64 IBM Corporation, 90, 119, 291, vii IBM Harvest computer, i IBM MVS/370 operating system,

276, 284 IBM Operating System/360, See

Operating System/360 IBM OS-2 operating system, 284 IBM PC computer, 260, 264, 284 IBM SAGE ANFSQ/7 data processing system, 216, 305 IBM System/360 computer family

44, 45, 62, 64 IBM System/360 Model 165, 98 IBM System/360 Model 30, 45, 47 IBM System/360 Model 65, 99 IBM System/360 Model 75, 47 IBM. System/360 Principles of

Operation, 62 IBM VM/360 operating system,

IBSYS operating system for the

7090, 56 Ichikawa, T., 302 icon, 260 ideas, as stage of creation, 15 IEEE Computer magazine, vii

IF...THEN...ELSE, 144 Ihm, C. C, 308

implementation, 15, 45, 64, 143,

209, 233, 234, 238, 256, 266 implementations, multiple, 68 implementer, 47, 54, 62, 66 incorporation, direct, 66, 118,

241, 264 incremental development, 200,

incremental-build model, 212,

267,270 indenting, 174 information hiding, 78, 271, 308 information theory, 212 inheritance, 220, 222, 273 initialization, 174 input range, 6,165, 248 input-output format, 165 instrumentation, 129 integrity, conceptual, 35, 36, 42,

43, 62, 80, 142, 255, 257, 260,

interaction, as part of creation,

15, 209 first of session, 146 interactive debugging, 34,146 interactive programming, 136,

244, 245, 246 interface, 6, 32, 62, 66, 79, 118,

120, 122, 241, 243, 255, 257,

264, 271, 282, 286, 306 metaprogramming, 287 module, 268

WIMP, 234, 260, 263 Interlisp, 187 International Computers Limited,

89, 133, 293, xi Internet, 306 interpreter, for space-saving, 102 invisibility, 185, 216, 241
