### Index

### Coding War Games, 276

coding, 20, 237 Coggins, J. M., 220, 221, 305, viii Coleman, D., 306 command key, 263 command, 261, 286, 287, 306 comment, 172, 249 committee, 17, 74, 79 communication, 16, 17, 35, 54,

61, 73, 78, 79, 88, 100, 111,

183,232,233,234,235,236,

240, 274 compatibility, 63, 64, 68 compile-time operation, 66 compiler, 132 complexity, 182, 211, 226, 233,

arbitrary, 184, 211 conceptual, 210 component debugging, 144 component, 223, 230, 239, 284,

dummy, 148 comprehensibility, 186 computer facility, 128 conceptual construct, 182, 186,

conceptual integrity, 35, 36, 42,

62, 80, 142, 184, 232, 233,

255, 257, 260, 264 conceptual structure, 180 conference, 66 conformity, 184 Conger, S. A., 214, 304 Conklin, J., 259, 306 control program, 91, 93 convergence of debugging, 9 Conway, M. E., Ill, 297 Conway, R. W., 47, 294 Cooley, J. W., 102 copilot, 32

Coqui, H., 217, 305 Corbatd, F. J., 93, 146, 237, 293,

297, 298, 299, 300, xi Cornell University, 47 Cosgrove, J., 117, 118, 241, 298 cost, 6, 16, 87, 121, 182, 224, 233,

242, 274 cost, development, 198 front-loaded, 221 courage, managerial, 12, 21, 119,

153, 221, 242, 274 court, for design disputes, 66 Cox, B. J., 210, 212, 304 Crabbe, G., 163 creation, component stages, 15,

45, 143 creative joy, 7, 120, 280 creative style, 47 creative work, 46 creativity, 278, 280 critical-path schedule, 89,156,

158, 247, 301 Crockwell, D., 87 Crowley, W. R., 132 cursor, 261 customizability, 219 customization, 222

d'Orbais, J., 41

Dahl, O. J., 300, 308

Daley, R. C, 300 data base, 108 data service, 131 database, 198, 223, 240, 283, 285 datatype, abstract, 189 date, estimated, 158 scheduled, 158 debugging aid, 128 debugging, component, 144 high-level language, 135 interactive, 34, 136, 146, 245
