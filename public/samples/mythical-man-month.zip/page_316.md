### Index Merwin, R. E., 299

### Merwin-Dagget, M., 300

metaphor, 260 metaprogramming, 285 microcomputer revolution, 214,

microfiche, 77, 235 Microsoft Corporation, 246, 270 Microsoft Windows, 260 Microsoft Word 6.0, 258, 306 Microsoft Works, 219 milestone, 22, 25,154, 158, 247,

248, 270 Mills, H. D., 32, 33, 201, 267,

271, 294, 299, 300, 303, 307 MILSPEC documentation, 248 mini-decision, 63, 111, 234, 240 MiniCad design program, 285 MIT, 93, 121, 146, 287, 293, xi mnemonic name, 174 model, 255, 256, 274, 307

COCOMO, 273 incremental-build, 212, 267,

spiral, 303, 307 waterfall, 264, 307 Modula, 189, 203 modularity, 118, 188, 220 module, 101,122, 143, 241, 243,

245, 269, 271, 273, 285 modules, number of, 122 Mooers, C. N., 44 Moore, S. E., xii Morin, L. H., 88, 296 Mostow, J., 302 mouse, 307 moving projects, 277 Mozart, W. A. 202 MS-DOS, 203, 255, 284 Multics, 93, 136, 146, 237, 298, -

299,300

multiple implementations, 68

MVS/370, 203 Naamad, A., 305

Nanus, B., 88, 296

Naur, P., 64 Needham, R. M., 298 Nelson, E. A., 297 nesting, as documentation aid,

network nature of communication, 79 Neustadt, R. E., 295 Newell, A., 64, 296 Noah, 97 North Carolina State University,

notebook, status, 33 system, 147 Nygaard, 308

object 285 object-oriented design, 302 object-oriented programming,

189, 219, 273 objective, 8, 75,108,110, 117, 239 cost and performance, 49 space and time, 49 obsolescence, 9, 26,123 off-the-shelf package, 198 office space, 242 Ogdin, J. L., 293, 298 open system, 283 operating system, 128, 238, 243,

Operating System/360, 43, 45, 47,

56, 76, 93, 129, 234, 235, 237,

243, 271, 276, 295, i, x optimism, 14, 212, 231 option, 101, 165, 238 Orbais, J. d', 41
