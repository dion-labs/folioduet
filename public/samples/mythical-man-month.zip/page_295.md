### Notes and References

puter programming management?" in G. F, Weinwurm (ed.), On the Management of Computer Programming. Philadelphia: Auerbach, 1971, pp. 35-42.

### Chapter 5

1. Strachey, C., "Review of Planning a Computer System," Comp. /., 5, 2 (July, 1962), pp. 152-153. 2. This applies only to the control programs. Some of the compiler teams in the OS/360 effort were building their third or fourth systems, and the excellence of their products shows it. 3. Shell, D. L., "The Share 709 system: a cooperative effort"; Greenwald, I. D., andM. Kane, "The Share 709 system: programming and modification"; Boehm, E. M., and T. B. Steel, Jr., "The Share 709 system: machine implementation of symbolic programming"; all in /ACM, 6, 2 (April, 1959), pp.123-140.

Chapter6

1. Neustadt, R. E., Presidential Power. New York: Wiley, 1960, Chapter 2. 2. Backus, J. W., "The syntax and semantics of the proposed international algebraic language." Proc, Intl. Con/. Inf. Proc. UNESCO, Paris, 1959, published by R. Oldenbourg, Munich, and Butterworth, London. Besides this, a whole collection of papers on the subject is contained in T. B. Steel, Jr. (ed.), Formal Language Description Languages for Computer Programming. Amsterdam: North Holland, (1966). 3. Lucas, P., and K. Walk, "On the formal description of PL/I," Annual Review in Automatic Programming Language. New York: Wiley, 1962, Chapter 2, p. 2.

4. Iverson, K. E., A Programming Language. New York: Wiley, 1962, Chapter 2.
