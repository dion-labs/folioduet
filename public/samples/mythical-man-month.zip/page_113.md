### The Documentary Hypothesis

### The hypothesis:

Amid a wash of paper, a small number of documents become the critical pivots around which every project's management revolves.

These are the manager's chief personal tools.

W. Bengough, "Scene in the old Congressional Library," 1897
