Good cooking fakes time. If you are made to wait, it is to serve you better, and to please you.
