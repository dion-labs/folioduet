### Notes and References

12. A good treatment of development of specifications and of system build and test is given by F. M. Trapnell, "A systematic approach to the development of system programs," AFIPS Proc S/CC, 34 (1969) pp. 411-418. 13. A real-time system will require an environment simulator. See, for example, M. G. Ginzberg, "Notes on testing realtime system programs," IBM Sys. /., 4, 1 (1965), pp. 58-72. 14. Lehman, M., and L. Belady, "Programming system dynamics," given at the ACM SIGOPS Third Symposium on Operating System Principles, October, 1971.

### Chapter 14

1. See C. H. Reynolds, "What's wrong with computer programming management?" in G. F. Weinwurm (ed.), On the Management of Computer Programming. Philadelphia: Auerbach, 1971, pp. 35-42. 2. King, W. R., and T. A. Wilson, "Subjective time estimates in critical path planning—a preliminary analysis," Mgt. Sci., 13, 5 (Jan., 1967), pp. 307-320, and sequel, W. R. King, D. M. Witterrongel, K. D. Hezel, "On the analysis of critical path time estimating behavior," Mgt. Sci., 14, 1 (Sept., 1967), pp. 79-S4. 3. For a fuller discussion, see Brooks, F. P., and K. E. Iverson, Automatic Data Processing, System/360 Edition, New York: Wiley, 1969, pp. 428-430. 4. Private communication.

### Chapter 15

1. Goldstine, H. H., and J. von Neumann, "Planning and coding problems for an electronic computing instrument," Part II, Vol. 1, report prepared for the U.S. Army Ordinance Department, 1947; reprinted in J. von Neumann, Collected Works, A. H. Taub (ed.), Vol. v., New York: McMillan, pp. 80-151.
