Notes and References Chapter 3

1. Sackman, H., W. J. Erikson, and E. E. Grant, "Exploratory experimental studies comparing online and offline programming performance," CACM, 11, 1 (Jan., 1968), pp. 3- 11.

2. Mills, H., "Chief programmer teams, principles, and procedures," IBM Federal Systems Division Report FSC 71-

5108, Gaithersburg, Md., 1971.

3. Baker, F. T., "Chief programmer team management of production programming," IBM Sys. J., 11, 1 (1972).

### Chapter 4

1. Eschapasse, M., Reims Cathedral, Caisse Narionale des Monuments Historiques, Paris, 1967. 2. Brooks, F. P., "Architectural philosophy," in W. Buchholz (ed.), Planning A Computer System. New York: McGraw-Hill, 1962. 3. Blaauw, G. A., "Hardware requirements for the fourth generation," in F. Gruenberger (ed.), Fourth Generation Computers. Englewood Cliffs, N.J.: Prentice-Hall, 1970.

4. Brooks, F. P., and K. E. Iverson, Automatic Data Processing, System/360 Edition. New York: Wiley, 1969, Chapter 5. 5. Glegg, G. L., The Design of Design. Cambridge: Cambridge Univ. Press, 1969, says "At first sight, the idea of any rules or principles being superimposed on the creative mind seems more likely to hinder than to help, but this is quite untrue in practice. Disciplined thinking focusses inspiration rather than blinkers it." 6. Conway, R. W., "The PL/C Compiler," Proceedings of a Conf. on Definition and Implementation of Universal Programming Languages. Stuttgart, 1970. 7. For a good discussion of the necessity for programming technology, see C. H. Reynolds, "What's wrong with com-
