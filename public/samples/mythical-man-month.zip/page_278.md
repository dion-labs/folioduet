The Mythical Man-Month after 20 Years

preserved among the various associations, in observing the principle of subsidiary function, the stronger will be the social authority and effectiveness and the happier and more prosperous the condition of the State.19

Schumacher goes on to interpret:

The Principle of Subsidiary Function teaches us that the centre will gain in authority and effectiveness if the freedom and responsibility of the lower formations are carefully preserved, with the result that the organization as a whole will be "happier and more prosperous."

How can such a structure be achieved?. . . . The large organization will consist of many semi-autonomous units, which we may call quasi-firms. Each of them will have a large amount of freedom, to give the greatest possible chance to creativity and entrepreneurship. . . . Each quasi-firm must have both a profit and loss account, and^a balance sheet.20

Among the most exciting developments in software engineering are the early stages of putting such organizational ideas into practice. First, the microcomputer revolution created a new software industry of hundreds of start-up firms, all of them starting small, and marked by enthusiasm, freedom, and creativity. The industry is changing now, as many small companies are being acquired by larger ones. It remains to be seen if the larger acquirers will understand the importance of preserving the creativity of smallness.

More remarkably, high management in some large firms have undertaken to delegate power down to individual software project teams, making them approach Schumacher's quasi-firms in structure and responsibility. They are surprised and delighted at the results.

Jim McCarthy of Microsoft described to me his experience at emancipating his teams:

Each feature team (30-40 people) owns its feature set, its schedule, and even its process of how to define, build, ship. The team is made
