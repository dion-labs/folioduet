Notes and References Chapter 18

1. Boehm, B. W., Software Engineering Economics, Englewood Cliffs, N.J.: Prentice-Hall, 1981, pp. 81^84. 2. McCarthy, J., "21 Rules for Delivering Great Software on Time," Software World USA Conference, Washington (Sept., 1994).

### Chapter 19

Material quoted without citation is from personal communications. 1. On this painful subject, see also Niklaus Wirth "A plea for lean software," Computer, 28, 2 (Feb., 1995), pp. 64-68. 2. Coleman, D., 1994, "Word 6.0 packs in features; update slowed by baggage," MacWeek, 8, 38 (Sept. 26, 1994), p. 1. 3. Many surveys of machine language and programming language command frequencies after fielding have been published. For example, see J. Hennessy and D. Patterson, Computer Architecture. These frequency data are very useful for building successor products, although they never exactly apply. I know of no published frequency estimates prepared before the product was designed, much less comparisons of a priori estimates and a posteriori data. Ken Brooks suggests that bulletin boards on the Internet now provide a cheap method of soliciting data from prospective users of a new product, even though only a self-selected set responds. 4. Conklin, J., and M. Begeman, "gIBIS: A Hypertext Tool for Exploratory Policy Discussion," ACM Transactions on Office Information Systems, Oct. 1988, pp. 303-331. 5. Englebart, D., and W. English, "A research center for augmenting human intellect," AFIPS Conference Proceedings, Fall Joint Computer Conference, San Francisco (Dec. 9-11, 1968), pp. 395-410.

6. Apple Computer, Inc., Macintosh Human Interface Guidelines, Reading, Mass.: Addison-Wesley, 1992.
