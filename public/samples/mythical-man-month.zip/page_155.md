### Hatching a Catastrophe

None love the bearer of bad news.

How does a project get to be a year late?

. . , One day at a time.

A. Canova, "Ercole e lica," 1802. Hercules hurls to his death the messenger Lycas, who innocently brought the death-garment. Scala/Art Resource, NY
