### Notes and References

2. Private communication, 1957. The argument is published in Iverson, K. E., "The Use of APL in Teaching," Yorktown, N.Y.: IBM Corp., 1969. 3. Another list of techniques for PL/I is given by A. B. Walter and M. Bohl in "From better to best—tips for good programming," Software Age, 3,11 (Nov., 1969), pp. 46-50.

The same techniques can be used in Algol and even Fortran. D. E. Lang of the University of Colorado has a Fortran formatting program called STYLE that accomplishes such a result. See also D. D. McCracken and G. M. Weinberg, "How to write a readable FORTRAN program," Datamation, 18, 10 (Oct., 1972), pp. 73-77.

### Chapter 16

1. The essay entitled "No Silver Bullet" is from Information Processing 1986, the Proceedings of the IFIP Tenth World Computing Conference, edited by H.-J. Kugler (1986), pp. 1069-76. Reprinted with the kind permission of IFIP and Elsevier Science B. V., Amsterdam, The Netherlands. 2. Parnas, D. L., "Designing software for ease of extension and contraction," IEEE Trans, on SE, 5,2 (March, 1979), pp. 128- 138. 3. Booch, G., "Object-oriented design," in Software Engineering with Ada. Menlo Park, Calif.: Benjamin/Cummings, 1983. 4. Mostow, J., ed., Special Issue on Artificial Intelligence and Software Engineering, /£££ Trans, on SE, 11, 11 (Nov., 1985). 5. Parnas, D. L., "Software aspects of strategic defense systems," Communications of the ACM, 28, 12 (Dec., 1985), pp. 1326-1335. Also in American Scientist, 73, 5 (Sept.-Oct., 1985), pp. 432-440. 6. Balzer, R., "A 15-year perspective on automatic programming," in Mostow, op. cit. 7. Mostow, op. cit. 8. Parnas, 1985, op. cit.
