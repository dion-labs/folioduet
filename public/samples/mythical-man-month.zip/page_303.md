### Notes and References

9. Raeder, G., "A survey of current graphical programming techniques," in R. B. Grafton and T. Ichikawa, eds., Special Issue on Visual Programming, Computer, 18, 8 (Aug., 1985), pp. 11-25. 10. The topic is discussed in Chapter 15 of this book. 11. Mills, H. D., "Top-down programming in large systems," Debugging Techniques in Large Systems, R. Rustin, ed., Englewood Cliffs, N.J., Prentice-Hall, 1971. 12. Boehm, B. W., "A spiral model of software development and enhancement," Computer, 20, 5 (May, 1985), pp. 43-57.

### Chapter 17

Material quoted without citation is from personal communications. 1. Brooks, F. P., "No silver bullet—essence and accidents of software engineering," in Information Processing 86, H, J. Kugler, ed. Amsterdam: Elsevier Science (North Holland), 1986, pp. 1069^1076. 2. Brooks, F. P., "No silver bullet—essence and accidents of software engineering," Computer 20,4 (April, 1987), pp. 10-19. 3. Several of the letters, and a reply, appeared in the July, 1987 issue of Computer.

It is a special pleasure to observe that whereas "NSB" received no awards, Bruce M. Skwiersky's review of it was selected as the best review published in Computing Reviews in 1988. E. A. Weiss, "Editorial," Computing Reviews (June, 1989), pp. 283-284, both announces the award and reprints Skwiersky's review. The review has one significant error: "sixfold" should be "106." 4. "According to Aristotle, and in Scholastic philosophy, an accident is a quality which does not belong to a thing by right of that thing's essential or substantial nature but occurs in it as an effect of other causes." Webster's New International Dictionary of the English Language, 2d ed., Springfield, Mass.: G. C. Merriam, 1960.
