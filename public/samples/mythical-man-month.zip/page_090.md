The director may be boss, and the producer his right-hand man. Robert Heinlein, in The Man Who Sold the Moon, describes such an arrangement in a graphic for-instance:
