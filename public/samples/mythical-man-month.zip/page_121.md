### Plan toThrow One Away

There is nothing in this world constant but inconstancy.

It is common sense to take a method and try it. If it fails, admit it frankly and try another. But above all try

FRANKLIN D. ROOSEVELT Collapse of the aerodynamically misdesigned Tacoma Narrows Bridge,
