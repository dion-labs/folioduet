### Don't Build One to Throw Away

"Plan to throw one away; you will, anyhow." This I now perceive to be wrong, not because it is too radical, but because it is too simplistic.

The biggest mistake in the "Build one to throw away" concept is that it implicitly assumes the classical sequential or waterfall model of software construction. The model derives from a Gantt chart layout of a staged process, and it is often drawn as in Figure 19.1. Win ton Royce improved the sequential model in a classic 1970 paper by providing for

* Some feedback from a stage to its predecessors * Limiting the feedback to the immediately preceding stage only, so as to contain the cost and schedule delay it occasions.

He preceded The MM-M in advising builders to "build it twice."8

Chapter 11 is not the only one tainted by the sequential waterfall model; it runs through the book, beginning with the scheduling rule in Chapter 2. That rule-of-thumb allocates 1/3 of the schedule to planning, 1/6 to coding, 1/4 to component test, and 1/4 to system test.

Fig. 19.1 Waterfall model of software construction
