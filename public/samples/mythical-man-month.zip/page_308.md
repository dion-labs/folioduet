### Notes and References

nical Report (Feb., 1971); Parnas, D. L., "A technique for software module specification with examples," Comm. ACM, 5, 5 (May, 1972), pp. 330-336; Parnas, D. L. (1972). "On the criteria to be used in decomposing systems into modules," Comm. ACM, 5,12 (Dec., 1972), pp. 1053-1058. 14. The ideas of objects were initially sketched by Hoare and Dijkstra, but the first and most influential development of them was the Simula-67 language by Dahl and Nygaard.

15. Boehm, B. W., Software Engineering Economics, Englewood Cliffs, N.J.: Prentice-Hall, 1981, pp. 83-94; 470-472.

16. Abdel-Hamid, T., and S. Madnick, Software Project Dynamics:

An Integrated Approach, ch. 19, "Model enhancement and

Brooks's law." Englewood Cliffs, N.J.: Prentice Hall, 1991. 17. Stutzke, R. D., "A Mathematical Expression of Brooks's Law." In Ninth International Forum on COCOMO and Cost Modeling. Los Angeles: 1994.

18. DeMarco, T., and T. Lister, Peopleware: Productive Projects and Teams. New York: Dorset House, 1987. 19. Pius XI, Encyclical Quadragesima Anno, [Ihm, Claudia Carlen, ed., The Papal Encyclicals 1903-1939, Raleigh, N.C.: McGrath, p. 428.]

20. Schumacher, E. E, Small Is Beautiful: Economics as if People

### Mattered, Perennial Library Edition. New York: Harper and

Row, 1973, p. 244. 21. Schumacher, op. cit., p. 34. 22. A thought-provoking wall poster proclaims: "Freedom of the press belongs to him who has one." 23. Bush, V., "That we may think," ^Atlantic Monthly, 176, 1 (April, 1945), pp. 101-108. 24. Ken Thompson of Bell Labs, inventor of Unix, realized early the importance of big screens for programming. He devised a way to get 120 lines of code, in two columns, onto his primitive Tektronix electron-storage tube. He clung to this terminal through a whole generation of small-window, fast tubes.
