### "No Silver Bullet" Refired

Every bullet has its billet.

WILLIAM III OF ENGLAND, PRINCE OF ORANGE Whoever thinks a faultless piece to see,

Thinks what never was, nor is, nor ever shall be.

ALEXANDER POPE, AN ESSAY ON CRITICISM Assembling a structure from ready-made parts, 1945

### The Bettman Archive
