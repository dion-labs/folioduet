### Propositions of The

### Mythical Man-Month: True or False?
