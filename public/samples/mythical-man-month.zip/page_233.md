### I Chapter 5. The Second-System Effect

4.2 "The ratio of function to conceptual complexity is the ul-

timate test of system design," not just the richness of function. [This ratio is a measure of ease of use, valid over both simple and difficult uses.] 4.3 To achieve conceptual integrity, a design must proceed from one mind or a small group of agreeing minds. 4.4 "Separation of architectural effort from implementation is a very powerful way of getting conceptual integration on very large projects." [Small ones, too.] 4.5 "If a system is to have conceptual integrity, someone must control the concepts. That is an aristocracy that needs no apology." 4.6 Discipline is good for art. The external provision of an architecture enhances, not cramps, the creative style of an implementing group. 4.7 A conceptually integrated system is faster to build and to test. 4.8 Much of software architecture, implementation, and realization can proceed in parallel. [Hardware and software design can likewise proceed in parallel.]

Chapter 5.

### The Second-System Effect

5.1 Early and continuous communication can give the architect good cost readings and the builder confidence in the design, without blurring the clear division of responsibilities. 5.2 How an architect can successfully influence implementation: • Remember that the builder has the creative responsibility for implementation; the architect only suggests. • Always be ready to suggest a way of implementing anything one specifies; be prepared to accept any other equally good way. • Deal quietly and privately in such suggestions. 9 Be ready to forgo credit for suggested improvements.
