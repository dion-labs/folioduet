### Index

scaling up, 36,116, 240, 288

### Scalzi, C A., 300

schedule, 79,108, 111, 154, 239,

244, 247, 265, 273, See Late project cost-optimum, 274 scheduler, 57 scheduling, 14, 129 Schumacher, E. F., 277, 279,

screen, 194, 201, 268, 287, 308 second-system effect, 51, 234,

257,259 secretary, 33 security, 183 self-documenting program, 118,

171, 249 Selin, I., 219 semantics, 44, 64, 66, 225, 261,

Shakespeare, W., 141, 255 Shannon, E. C. , 212 Share 709 Operating System (SOS), 295 Share Operating System for the

IBM 709, 57 Shell, D. L., 295 Sherman, M., 189 Sherman, R., 305 short cuts, 263 shrink-wrapped software, 218,

219, 223, 257, 279, 282, 284 Shtul-Trauring, A,, 305 side effect, 65, 122, 243 silver bullet, 179, 207, 212, 214,

226, 303, 304 simplicity, 44, 181, 186 Simula-67, 189, 308 simulator, 234, 244 environment, 131

logic, 65, 131 performance, 99 size, program, 30, 98,129,135,

Skwiersky, B. M., 303 slippage, schedule, See Late project Sloane, J. C., xii Small is Beautiful, 277 Smalltalk, 203, 220 Smith, S., 97 snapshot, 145 Snyder, Van, 222 sociological barrier, 119 Sedahl, L., 211 Software Engineering Economics,

Software Engineering Institute,

software industry, 282 Software Project Dynamics, 274 Sophocles, 153,155 space allocation, 108, 111 space, memory, 238 office, 203, 276 program, See size, program, specialization of function, 35, 79,

specification, 195, 200, 245, 256,

266, 301, 304 architectural, 43, 142, 245 functional, 32, 48, 49, 62, 75,

108, 110 interface, 75 internal, 75 performance, 32 testing the, 142 speed, program, 30, 98,135 spiral, pricing-forecasting, 109 spreadsheet, 198, 280, 281
