### Calling the Shot

Productivity seems constant in tenns of elementary statements, a conclusion that is reasonable in terms of the thought a statement requires and the errors it may include."

Programming productivity may be increased as much as five times when a suitable high-level language is used.18
