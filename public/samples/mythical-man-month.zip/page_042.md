### The Surgical Team These studies revealed large individual differences between

high and low performers, often by an order of magnitude.
