### Index

iteration, 199, 267

Iverson, K. E., 64, 102, 170, 291,

294, 295, 296, 297, 300, 301,

Jacopini, A., 144, 300 Jobs, S., 260

Jones, C., 217, 218, 222, 223, 224,

joys of the craft, 7

### Kane, M., 295

keyboard, 262 Keys, W. J., 169 King, W. R., 301 Knight, C. R., 3 Knuth, D. E., 102, 297 Kugler, H. J., 303

label, 174

### Lachover, H., 305

Lake, C., 291 Landy, B., 298 Lang, D. E., 302 language description, formal, 181 language translator, 93 language, fourth-generation, 283 high-level, 118,135, 143, 146,

186, 194, 225, 237, 241, 244,

245, 248, 249 machine, 180, 225 programming, 68, 180, 186, 225 scripting, 287 late project, 13, 89, 217, 235, 246,

275, 306 lawyer, language, 34 Lehman, M., 122, 123, 150, 243,

246, 298, 301 Lewis, C. S., 123, 298 library, 187, 222, 239, 244, 272,

class, 225 macro, 34 program, 132 linkage editor, 56, 282 Lister, T., 276, 308 Little, A. D., 287 Locken, O. S., 76 Lowry, E. S., 300 Lucas, P., 295 Lukasik, S., 211

Macintosh WIMP interface, 234,

260, 263 Madnick, S., 274, 308 magic, 7, 142, 226 maintenance, 118, 242 man-month, 16, 231, 273 management information system (MIS), 107, 111, 219, 239,

240, 285 manual, 62, 239, 258, 263 System/360, 62 market, mass, 180,197, 218, 223,

matrix management, 222 matrix-type organization, 79 Mausner, B., 210, 304 Mayer, D. B., 297 McCarthy, J., 247, 270, 278, 306, via McCracken, D. D., 302 McDonough, E., 300 Mealy, G., xi measurement, 222 medium of creation, tractable, 7,

15, 117 meeting, problem action, 157 status review, 75, 157 memory use pattern, 129, 239 mentor, 203, 275 menu, 260
