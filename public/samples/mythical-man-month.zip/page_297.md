### Notes and References

D. B. Mayer and A. W. Stalnaker, "Selection and evaluation of computer personnel/' Proc. 23rd ACM. Con/., 1968, p. 661.) 7. Aron, J., private communication. 8. Paper given at a panel session and not included in the AFIPS Proceedings. 9. Wolverton, R. W., "The cost of developing large-scale software," IEEE Trans, on Computers, C-23, 6 (June, 1974) pp. 615-636. This important recent paper contains data on many of the issues of this chapter, as well as confirming the productivity conclusions. 10. Corbato, F. J., "Sensitive issues in the design of multi-use systems," lecture at the opening of the Honeywell EDP Technology Center, 1968. 11. W. M. Taliaffero also reports a constant productivity of 2400 statements/year in assembler, Fortran, and Cobol. See "Modularity. The key to system growth potential," Software, I, 3 (July 1971) pp. 245-257. 12. E. A. Nelson's System Development Corp. Report TM-3225, Management Handbook for the Estimation of Computer Programming Costs, shows a 3-to-l productivity improvement for high-level language (pp. 66-67), although his standard deviations are wide.

### Chapter 9

1. Brooks, F. P. and K. E. Iverson, Automatic Data Processing, System/360 Edition. New York: Wiley, 1969, Chapter 6. 2. Knuth, D. E., The Art of Computer Programming, Vols. 1-3. Reading, Mass.: Addison-Wesley, 1968, ff.

### Chapter 10

1. Conway, M. E., "How do committees invent?" Datamation, 14, 4 (April, 1968), pp. 28-31.
