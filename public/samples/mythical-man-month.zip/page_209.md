### Obscure Writing Will Be Misunderstood

I buy hardware and software chiefly by the "happy user" test—conversations with bona fide cash-paying customers who use the product and are pleased. Likewise, I shall most readily believe a silver bullet has materialized when a bona fide independent user steps forth and says, "I used this methodology, tool, or product, and it gave me a tenfold improvement in software productivity."

Many correspondents have made valid emendations or clarifications. Some have undertaken point-by-point analysis and rebuttal, for which I am grateful. In this chapter, I shall share the improvements and address the rebuttals.

### Obscure Writing Will Be Misunderstood

Some writers show that I failed to make some arguments clear.

Accident. The central argument of "NSB" is as clearly stated in the Abstract to Chapter 16 as I know how to put it. Some have been confused, however, by the terms accident and accidental, which follow an ancient usage going back to Aristotle.4 By accidental, I did not mean occurring by chance, nor misfortunate, but more nearly incidental, or appurtenant.

I would not denigrate the accidental parts of software construction; instead I follow the English dramatist, detective story writer, and theologian Dorothy Sayers in seeing all creative activity to consist of (1) the formulation of the conceptual constructs, (2) implementation in real media, and (3) interactivity with users in real uses.5 The part of software building I called essence is the mental crafting of the conceptual construct; the part I called accident is its implementation process.

A question of fact. It seems to me (although not to everyone) that the truthfulness of the central argument boils down to a question of fact: What fraction of total software effort is now associated with the accurate and orderly representation of the conceptual construct, and what fraction is the effort of mentally crafting the constructs? The finding and fixing of flaws falls
