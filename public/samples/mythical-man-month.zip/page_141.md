### The Whole and the Parts
