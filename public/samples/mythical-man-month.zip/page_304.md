### Notes and References

5. Sayers, Dorothy L., The Mind of the Maker. New York: Harcourt, Brace, 1941. 6. Glass, R. L., and S. A. Conger, "Research software tasks: Intellectual or clerical?" Information and Management, 23, 4 (1992). The authors report a measurement of software requirements specification to be about 80% intellectual and 20% clerical. Fjelstadt and Hamlen, 1979, get essentially the same results for application software maintenance. I know of no attempt to measure this fraction for the whole end-toend task. 7. Herzberg, F., B. Mausner, and B. B. Sayderman. The Motivation to Work, 2nd ed. London: Wiley, 1959. 8. Cox, B. J., "There is a silver bullet," Byte (Oct., 1990), pp. 209-218. 9. Harel, D., "Biting the silver bullet: Toward a brighter future for system development," Computer (Jan., 1992), pp. 8-20. 10. Parnas, D. L., "Software aspects of strategic defense systems," Communications of the ACM, 28, 12 (Dec., 1985), pp. 1326-1335. 11. Turski, W. M., "And no philosophers' stone, either," in Information Processing 86, H. J. Kugler, ed. Amsterdam: Elsevier Science (North Holland), 1986, pp. 1077-1080. 12. Glass, R. L., and S. A. Conger, "Research Software Tasks: Intellectual or Clerical?" Information and Management, 23, 4 (1992), pp. 183-192.

13. Review of Electronic Digital Computers, Proceedings of a Joint

AIEE-IRE Computer Conference (Philadelphia, Dec. 10-12,

1951). New York: American Institute of Electrical Engineers, pp. 13-20.

14. Ibid., pp. 36, 68, 71, 97.

15. Proceedings of the Eastern Joint Computer Conference, (Washington, Dec. 8-10, 1953). New York: Institute of Electrical Engineers, pp. 45-47.

16. Proceedings of the 1955 Western Joint Computer Conference (Los
