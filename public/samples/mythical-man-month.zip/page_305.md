### Notes and References

Angeles, March 1-3, 1955). New York: Institute of Electrical Engineers. 17. Everett, R. R., C. A. Zraket, and H. D. Bennington, "SAGE—A data processing system for air defense," Proceedings of the Eastern Joint Computer Conference, (Washington, Dec. 11-13, 1957). New York: Institute of Electrical Engineers. 18. Harel, D., H. Lachover, A. Naamad, A. Pnueli, M. Politi, R. Sherman, A. Shtul-Trauring, "Statemate: A working environment for the development of complex reactive systems," IEEE Trans, on SE, 16, 4 (1990), pp. 403^44.

19. Jones, C., Assessment and Control of Software Risks. Englewood Cliffs, N.J.: Prentice-Hall, 1994. p. 619. 20. Coqui, H., "Corporate survival: The software dimension,"

Focus '89, Cannes, 1989.

21. Coggins, James M., "Designing C + + libraries," C+ + Journal, \, 1 (June, 1990), pp. 25-32. 22. The tense is future; I know of no such result yet reported for a fifth use.

23. Jones, op. cit., p 604.

24. Huang, Weigiao, "Industrializing software production,"

Proceedings ACM 1988 Computer Science Conference, Atlanta,

1988. I fear the lack of personal job growth in such an arrangement. 25. The entire September, 1994 issue of IEEE Software is on reuse.

26. Jones, op. cit., p. 323.

27. Jones, op. cit., p. 329.

28. Yourdon, E., Decline and Fall of the American Programmer. Englewood Cliffs, N.J.: Yourdon Press, 1992, p. 221. 29. Glass, R. L., "Glass"(column), System Development, (January, 1988), pp. 4-5.
