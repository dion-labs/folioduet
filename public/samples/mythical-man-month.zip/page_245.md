### Chapter 13. The Whole and the Parts

and object-code speed have been made obsolete by the advance of language and compiler technology. 12.16 The only reasonable candidate for system programming today is PL/I. [No longer true.]

### Interactive Programming

12.17 Interactive systems will never displace batch systems for some applications. [Still true.] 12.18 Debugging is the hard and slow part of system programming, and slow turnaround is the bane of debugging. 12.19 Limited evidence shows that interactive programming at least doubles productivity in system programming.

Chapter 13. The Whole and the Parts

13.1 The detailed, painstaking architectural effort implied in Chapters 4, 5, and 6 not only makes a product easier to use, it makes it easier to build and reduces the number of system bugs that have to be found. 13.2 Vyssotsky says "Many, many failures concern exactly those aspects that were never quite specified." 13.3 Long before any code itself, the specification must be handed to an outside testing group to be scrutinized for completeness and clarity. The developers themselves cannot do this. (Vyssotsky) 13.4 "Wirth's top-down design [by stepwise refinement] is the most important new programming formalization of the [1965-1975] decade." 13.5 Wirth advocates using as high-level a notation as possible on each step. 13.6 A good top-down design avoids bugs in four ways. 13.7 Sometimes one has to go back, scrap a high level, and start over. 13.8 Structured programming, designing programs whose control structures consist only of a specified set that govern blocks of code (versus miscellaneous branching), is a
