### Chapter 8. Calling the Shot

Chapter 8. Calling the Shot

8.1 One cannot accurately estimate the total effort or schedule of a programming project by simply estimating the coding time and multiplying by factors for the other parts of the task. 8.2 Data for building isolated small systems are not applicable to programming systems projects. 8.3 Programming increases goes as a power of program size. 8.4 Some published studies show the exponent to be about 1.5. [Boehm's data do not at all agree with this, but vary from 1.05 to I.2.]1

8.5

Portman's ICL data show full-time programmers applying

only about 50 percent of their time to programming and debugging, versus other overhead-type tasks. 8.6 Aron's IBM data show productivity varying from 1.5 K lines of code (KLOC) per man-year to 10 KLOC/man-year as a function of the number of interactions among system parts. 8.7 Harr's Bell Labs data show productivities on operatingsystems-type work to run about 0.6 KLOC/man-year and on compiler-type work about 2.2 KLOC/man-year for finished products. 8.8 Brooks's OS/360 data agrees with Harr's: 0.6-0.8 KLOC/ man-year on operating systems and 2-3 KLOC/man-year on compilers. 8.9 Corbatd's MIT Project MULTICS data show productivity of 1.2 KLOC/man-year on a mix of operating systems and compilers, but these are PL/I lines of code, whereas all the other data are assembler lines of code! 8.10 Productivity seems constant in terms of elementary statements. 8.11 Programming productivity may be increased as much as five times when a suitable high-level language is used.
