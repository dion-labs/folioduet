### What Documentation Is Required?

What Documentation Is Required?

Different levels of documentation are required for the casual user of a program, for the user who must depend upon a program, and for the user who must adapt a program for changes in circumstance or purpose.

To use a program. Every user needs a prose description of the program. Most documentation fails in giving too little overview. The trees are described, the bark and leaves are commented, but there is no map of the forest. To write a useful prose description, stand way back and come in slowly:

1. Purpose. What is the main function, the reason for the program? 2. Environment. On what machines, hardware configurations, and operating system configurations will it run?

3. Domain and range. What domain of input is valid? What range of output can legitimately appear?

4. Functions realized and algorithms used. Precisely what does it do? 5. Input-output formats,, precise and complete.

6. Operating instructions, including normal and abnormal ending behavior, as seen at the console and on the outputs.

7. Options. What choices does the user have about functions?

Exactly how are those choices specified?

8. Running time. How long does it take to do a problem of specified size on a specified configuration? 9. Accuracy and checking. How precise are the answers expected to be? What means of checking accuracy are incorporated?

Often all this information can be set forth in three or four pages. That requires close attention to conciseness and precision. Most of this document needs to be drafted before the program is written, for it embodies basic planning decisions.

To believe a program. The description of how it is used must be supplemented with some description of how one knows it is working. This means test cases.
