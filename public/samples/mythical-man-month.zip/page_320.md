Index

staff group, 79 staffing, project, 21, 273 Stalnaker, A. W., 297 standard, 75, 168, 249, 283 standard, de facto, 264 Stanford Research Institute, 78,

Stanton, N., ix start-up firm, 278, 284 Statemate design tool, 305 status control, 108 status report, 157, 247 status review meeting, 157 status symbol, 81 Steel, T. B., Jr., 295 Strachey, C, 56, 146, 295, 300 straightforwardness, 44 Strategic Defense Initiative, 257 Stretch Operating System, 56, 99 structured programming, 32,144,

218, 241, 245 stub, 267 Stutzke, R. D., 275, 308 subroutine, 182, 272 Subsidiary Function, Principle of,

superior-subordinate relationship, 35 supervisory program, 146 support cost, 218 surgical team, 27, 120, 232 Sussenguth, E. H., 296 Swift, J., 115 synchronism in file, 171 syntax, 44, 64, 66, 225, 262 abstract, 64 system build, 147, 246, 301 system debugging, 132, 147 System Development

Corporation, 88, 297

system integration sublibrary, 133 system test, 19, 122,133,147 system, large, 31 programming, 6, 288 System/360 computer family, 296,

systems product, programming,

4,288

Tacoma Narrows Bridge, 115, 264 Taliaffero, W. M., 297

target machine, 129, 243, 244 Taub, A. H., 301 Taylor, B., 260 team, small, sharp, 30 technical director, role of, 79,

236, 256 technology, programming, 49,

102,128 telephone log, 68, 234 test case, 6, 34, 147, 166, 192,

248, 270 test, component, 20 system, 19, 122,133,147 tester, 34 testing advisor, 192 testing, 6 regression, 122, 242, 268 specification, 142 TESTRAN debugging facility, 57,

text-editing system, 134, 244 Thompson, K., 308 throw-away, 116, 241, 264 time, calendar, 14, 231 machine, 180 Time-Sharing System, PDP-10,

Time-Sharing System/360, 136,
