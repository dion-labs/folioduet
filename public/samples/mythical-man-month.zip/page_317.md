### Index

order-of-magnitude improvement, 208, 213, 215,

281, 291, vii organization chart, 108, 111, 239 organization, 74, 78,118, 235,

236,242 OS/360 Concepts and Facilities, 134 OS/360 Queued

### Telecommunications Access Method, 285 OS/360, See Operating System/

overlay, 54, 99, 129 overview, 165, 248 Ovid, 55

### Padegs, A., 62

paperwork, 108 Parnas families, 268 Parnas, D. L., 78, 190, 193, 212,

221, 224, 226, 236, 268, 271,

288, 296, 302, 304, 307, 308, via partitioning, 16, 231 Pascal programming language,

203, 285 Pascal, B., 123 pass structure, 166 Patrick, R. L., vii Patterson, D., 306 people, 29, 202, 276, 284 Peopleware: Productive Projects and

Teams, 276 perfection, requirement for, 8 performance simulator, 134 performance, 182, 258 PERT chart, 89, 156, 158, 247 pessimism, 212 Peter the Apostle, 171 philosopher's stone, 304 Piestrasanta, A. M., 160, xi

pilot plant, 116,240 pilot system, 298 pipes, 187 Pisano, A., 127 Pius XI, 277, 308 PL/C language, 47, 294 PL/I, 32, 47, 64, 66, 93, 135, 172,

203, 245, 299, 302 planning, 20 Plans and Controls organization,

160, 248 playpen, 133, 149, 244, 246 Pnueli, A., 305 pointing, 260 policed system, 65 Politi, M., 305 Pomeroy, J, W., 298 Poor Richard (Benjamin

Franklin), 87 Pope, Alexander, 207 Portman, C, 89, 237, 293, 296, xi power tools for the mind, 219 power, giving up, 277 practice, good software engineering, 193, 202 price, 109 PROCEDURE, 174 procedure, catalogued, 34 producer, role of, 79, 236, 256 product test, 69, 142, 234, 245 product, exciting, 203 programming system, 4, 230 programming, 5, 288 productivity equation, 197 productivity, programming, 21,

30, 88, 94, 135, 181, 186, 208,

213, 217, 237, 244, 245, 273,

276, 284 program clerk, 33 program library, 132 program maintenance, 120
