### The Second-System Effect

Adde parvum parvo magnus acervus erit.

{Add little to little and there will be a Ug pile. ]
