### The Other Face

What we do not understand we do not possess.

GOETHE O give me commentators plain,

Who with no deep researches vex the brain.

CRABBE A reconstruction of Stonehenge, the world's largest undocumented

computer.
