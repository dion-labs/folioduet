### Index

time-sharing, 187, 280, 282, 300 tool, 125,196, 243, 258, 280 power, for the mind, 219 toolsmith, 34, 128 top-down design, 220, 134, 143,

top-down programming, 303 Tower of Babel, 72, 235 TRAC language, 44 tracing, program 146 trade-off, size-function, 101 size-speed, 99, 101 training, time for, 18 transient area, 101, 238 Trapnell, F. M., 301, x, xi tree organization, 79 Truman, H. S., 61 TRW, Inc. , 273 Tukey, J. W., 102 turnaround time, 136, 187, 245,

turnover, personnel, 184 Turski, W. M., 213, 304 two-cursor problem, 261 two-handed operation, 262 type, abstract data, 188 type-checking, 220

Univac computer, 215 Unix workstation, 282

Unix, 187, 197, 203, 244, 284, 287,

University of North Carolina at

Chapel Hill, i user, 45, 117, 121, 165, 255, 258,

261, 266, 268, 271, 286 novice, 263 power, 263 USSR Academy of Sciences, xi utility program, 34, 128, 134

### Vanilla Framework design

methodology, 216 vehicle machine, 131 verification, 195 version, 118, 185, 217, 241, 268,

alpha, 240 beta 240 Vessey, 214 virtual environment, 281, i, viii virtual memory, 238 visual programming, 302 visual representation, 216 vocabularies, large, 224 Voice Navigator voice recognition system, 264 von Neumann, J., 170, 194, 301 Vyssotsky, V. A., 142, 158, 179,

185, 245, 248, 293, 299, xi

Walk, K. 295 Walter, A. B., 302

Ward, F., viii waterfall model, 264, 307 Watson, T. J., Jr., v, xi Watson, T. J., Sr., 164 Weinberg, G. M., 302 Weinwurm, G. F., 88, 295, 296,

Weiss, E. A., 303 Wells Apocalypse, The, 61 werewolf, 178, 180, 208 Wheeler, E., 279, viii William III of England, Prince of

Orange, 207 Wilson, T. A., 301 WIMP interface, 234, 260, 263 window, 260 Windows NT operating system,
