abstract data type, 188, 220,

accident, 179,182, 209, 214, 272,

280, 281, 303, viii accounting, 132 Ada, 188, 283 administrator, 33 Adobe Photoshop, 281 advancement, dual ladder of,

119, 242 advisor, testing, 192 Aiken, H. H., 291 airplane-seat metaphor, 194 Algol, 34, 44, 64, 68, 203, 295,

algorithm, 102, 239 allocation, dynamic memory, 57 alpha test, 142, 245, 266 alpha version, 240 Alto personal workstation, 260 ANSI, 168, 249 APL, 64, 98, 136, 175, 203, 302 Apple Computer, Inc., 264, 306 Apple Desk Top Bus, 307 Apple Lisa, 260 Apple Macintosh, 255, 258, 264,

284, 291, 306

### AppleScript, 287

architect, 37, 41, 54, 62, 66, 79,

100, 233, 236, 238, 255, 257 architecture, 44, 143, 233, 234,

245, 266 archive, chronological, 33 aristocracy, 39, 44, 46 Aristotle, 209, 303 Aron, J., 90, 93, 237, 297 ARPA network, 78 artificial intelligence, 190, 302 assembler, 132 authority, 8, 80, 231, 236 AutoCad, 285 AutoLisp, 285 automatic programming, 302

Bach, J. S., 47 Backus, J. W., 64, 295

Backus-Naur Form, 64 Baker, F. T., 36, 294, 300 Balzer, R., 302 Bardain, E. F., 2% barrier, sociological, 119 Begeman, M., 306 Belady, L., 122, 123, 150, 243,

246, 298, 301 Bell Northern Research, 270
