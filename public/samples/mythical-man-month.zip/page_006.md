<!-- pe:role=frontmatter pe:tts=skip -->
Dedication of the 1975 edition To two who especially enriched my IBM years:

<!-- pe:role=frontmatter pe:tts=skip -->
Thomas /. Watson, Jr.,

<!-- pe:role=frontmatter pe:tts=skip -->
whose deep concern for people still permeates his company, and Bob O. Evans,

<!-- pe:role=frontmatter pe:tts=skip -->
whose bold leadership turned work into

<!-- pe:role=frontmatter pe:tts=skip -->
Dedication of the 1995 edition To Nancy,

<!-- pe:role=frontmatter pe:tts=skip -->
God's gift to me.
