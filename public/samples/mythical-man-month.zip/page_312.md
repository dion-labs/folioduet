Index

debugging (continued) on-machine, 145 • sequential nature of, 17 system, 147 DEC PDP-8, 64 DEC VMS operating system, 284 DECLARE, 174 Defense Science Board Task Force on Military Software, i, vii,

Defense Science Board, 307 DeMarco, T., 218, 223, 224, 276,

283, 308, viii democracy, 44 Department of Defense, 266 dependability of debugging vehicle, 131 description; See specification, design change, 241 design-for-change, 272 designer, great, 180, 202, 304 desktop metaphor, 194, 260, 262 development, incremental, 200 diagram, 216 difference in judgement, 35 difference of interest, 35 Digitek Corporation, 102 Dijkstra, E. W., 144, 300, 308 director, technical, role of, 79,

236,256 discipline, 46, 54, 55, 233 Disk Operating System, IBM

1410-7010, 56, 57, 99 display terminal, 78, 129 division of labor, 79, 236 DO... WHILE, 144 document, 107, 239 documentation system, 134, 244 documentation, 6, 32, 33, 122,

164, 224, 235, 248

### DOD-STD-2167, 266, 307 DOD-STD-2167A, 307

Dragon voice recognition system,

Druffel, L., 307 dual ladder of advancement, 119,

dummy component, 148 dump, memory 133, 145 Durfee, B., 291

ease of use, 43, 98, 255, 258, 260,

262,263 Eastman Kodak Company, 285 Eckman, D., 298 editor, job description for, 33 text, 32, 34, 68, 128, 133, 134,

Einstein, A., 213 electronic mail, 234, 235 electronic notebook, 78, 235 Electronic Switching System, 90 encapsulation, 78, 220, 236, 271 Engelbart, D. C, 78, 260, 306 English, W., 306 entropy, 122, 243 environment, 6, 165,196 Erikson, W. J., 29, 30, 88, 294,

Ershov, A. P., 293, xi Eschapasse, M., 294 essence, 179,181,196, 214, 222,

272, 285, 303, viii estimating, 14, 21, 88, 109, 155,

231, 237, 239, 247, 301 Evans, B. O., v Everett, R. R., 305 Excel, 285, 286 expert system, 191 extension, 221, 268, 302
