### Calling the Shot
