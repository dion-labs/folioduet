Propositions of The Mythical Man-Month: True or False?

2.9 As a discipline, we lack estimating data. 2.10 Because we are uncertain about our scheduling estimates, we often lack the courage to defend them stubbornly against management and customer pressure. 2.11 Brooks's Law: Adding manpower to a late software project makes it later. 2.12 Adding people to a software project increases the total effort necessary in three ways: the work and disruption of repartitioning itself, training the new people, and added intercommunication.

### Chapter 3. The Surgical Team

3.1 Very good professional programmers are ten times as productive as poor ones, at same training and two-year experience level. (Sackman, Grant, and Erickson) 3.2 Sackman, Grant, and Erickson's data showed no correlation whatsoever between experience and performance. I doubt the universality of that result. 3.3 A small sharp team is best—as few minds as possible. 3.4 A team of two, with one leader, is often the best use of minds. [Note God's plan for marriage.] 3.5 A small sharp team is too slow for really big systems. 3.6 Most experiences with really large systems show the brute-force approach to scaling up to be costly, slow, inefficient, and to produce systems that are not conceptually integrated. 3.7 A chief-programmer, surgical-team organization offers a way to get the product integrity of few minds and the total productivity of many helpers, with radically reduced communication.

Chapter 4.

### Aristocracy, Democracy, and System Design

4.1 "Conceptual integrity is the most important consideration in system design."
