Index Windows operating system, 284

Wirth, N., 143, 245, 299, 306

Witterrongel, D. M., 301 Wizard-of-Oz technique, 271 Wolverton, R. W., 293, 297 workbook, 75 workstation, 196 World-Wide Web, 235, 281 wormhole, 287 Wright, W. V., 167

Xerox Palo Alto Research Center,

Yourdon, E., 218, 223, 224, 305,

zoom, 165, 248

### Zraket, C. A., 305
