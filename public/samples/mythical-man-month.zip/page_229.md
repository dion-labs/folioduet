### Propositions of The Mythical Man-Month

### True or False?

For brevity is very good,

Where we are, or are not understood.

SAMUEL BUTLER. Hudibras Brooks asserting a proposition, 1967
