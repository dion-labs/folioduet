The Mythical Man-Month after 20 Years

ments into which people market applications packages (in chronological order):

• The IBM MVS and VM environments • The DEC VMS environment • The Unix environment, in one flavor or another • The IBM PC environment, whether DOS, OS-2, or Windows

The Apple Macintosh environment.

The shrink-wrapped industry.

For the developer in the

shrink-wrapped industry, the economics are entirely different from those of the classical industry: development cost is divided by large quantities; packaging and marketing costs loom large. In the classical in-house application development industry, schedule and the details of function were negotiable, development cost might not be; in the fiercely competitive open market, schedule and function quite dominate development cost.

As one would expect, the starkly different economics have given rise to rather different programming cultures. The classical industry tended to be dominated by large firms with established management styles and work cultures. The shrinkwrapped industry, on the other hand, began as hundreds of start-ups, freewheeling and fiercely focused on getting the job done rather than on process. In this climate, there has always been a much greater recognition of the talent of the individual programmer, an implicit awareness that great designs come from great designers. The start-up culture has the capability of rewarding star performers in proportion to their contributions; in the classical software industry the sociology of corporations and their salary-management plans have always made this difficult. It is not surprising that many of the stars of the new generation have gravitated to the shrink-wrapped industry.

### Buy and Build—Shrink-Wrapped Packages As Components

Radically better software robustness and productivity are to be
