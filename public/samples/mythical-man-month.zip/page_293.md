### Notes and References Chapter 1

1. Ershov considers this not only a woe, but also a part of the joy. A. P. Ershov, "Aesthetics and the human factor in programming/' CACM, 15, 7 (July, 1972), pp. 501-505.

### Chapter 2

1. V. A. Vyssotsky of Bell Telephone Laboratories estimates that a large project can sustain a manpower buildup of 30 percent per year. More than that strains and even inhibits the evolution of the essential informal structure and its communication pathways discussed in Chapter 7. F. J. Corbat<5 of MIT points out that a long project must anticipate a turnover of 20 percent per year, and these must be both technically trained and integrated into the formal structure. 2. C. Portman of International Computers Limited says, "When everything has been seen to work, all integrated, you have four more months work to do." Several other sets of schedule divisions are given in Wolverton, R. W., "The cost of developing large-scale software," IEEE Trans, on Computers, C-23, 6 (June, 1974) pp. 615-636. 3. Figures 2.5 through 2.8 are due to Jerry Ogdin, who in quoting my example from an earlier publication of this chapter much improved its illustration. Ogdin, J. L., "The Mongolian hordes versus superprogrammer," Infosy'stems (Dec., 1972), pp. 20-23.
