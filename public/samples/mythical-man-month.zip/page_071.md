### Passing the Word

Hell sit here and he'll say, "Do this! Do that!" And nothing will happen.
