### after 20 Years

I know no way of judging the future but by the past.

You can never plan the future by the past.

### EDMUND BURKE Shooting the Rapids

### The Bettman Archive
