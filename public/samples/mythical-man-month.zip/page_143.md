I can call spirits from the vasty deep.

Why so can /, or so can any man; but will they come when you do call for them?

### KING HENRY W, PARTI The Walt Disney Company

### The Whole and the Parts
