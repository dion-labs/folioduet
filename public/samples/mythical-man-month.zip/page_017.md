### The Tar Pit

Een schip op het strand is een baken in zee.

{A ship on the beach is a lighthouse to the sea. ]
