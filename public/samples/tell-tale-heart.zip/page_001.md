# The Tell-Tale Heart

## By Edgar Allan Poe

<!-- pe:role=furniture -->
*Public domain · Project Gutenberg / standard edition*
